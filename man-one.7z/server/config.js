// server/config.js
module.exports = {
  AUTH0_DOMAIN: 'man100.auth0.com', // e.g., kmaida.auth0.com
  AUTH0_API_AUDIENCE: 'http://localhost:8083/api/', // e.g., 'http://localhost:8083/api/'
  MONGO_URI: 'mongodb://jason:abx3902@ds113749.mlab.com:13749/man'
};